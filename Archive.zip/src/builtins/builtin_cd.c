/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   builtin_cd.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: simarcha <simarcha@student.42barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/13 18:32:12 by simarcha          #+#    #+#             */
/*   Updated: 2024/05/13 18:32:15 by simarcha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

/*void	builtin_cd(char *path, char **env)
{

}*/

/*int	main(void)
{
	char	*path = "Users/simarcha/commonCore/";
	int		chdir_result;

	if (ft_strncmp(argv[0], "cd", 2) == 0)
	{

		chdir_result = chdir("/");
		if (chdir_result == -1)
			print_error("chdir function failed");
		printf("chdir result = %i\n", chdir_result);
	}
	return (0);
}*/
