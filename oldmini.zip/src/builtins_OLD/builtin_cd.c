/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   builtin_cd.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anovio-c <anovio-c@student.42barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/13 13:07:57 by anovio-c          #+#    #+#             */
/*   Updated: 2024/05/13 13:08:17 by anovio-c         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

/*void	builtin_cd(char *path, char **env)
{

}*/

/*int	main(void)
{
	char	*path = "Users/simarcha/commonCore/";
	int		chdir_result;

	if (ft_strncmp(argv[0], "cd", 2) == 0)
	{

		chdir_result = chdir("/");
		if (chdir_result == -1)
			print_error("chdir function failed");
		printf("chdir result = %i\n", chdir_result);
	}
	return (0);
}*/
